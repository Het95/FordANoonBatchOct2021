
public class Student implements Comparable<Student>
{
	String studentId;
	String studentCity;
	int score;
	
	public Student() {
		super();
	}

	public Student(String studentId, String studentCity, int score) {
		super();
		this.studentId = studentId;
		this.studentCity = studentCity;
		this.score = score;
	}

	@Override
	public String toString() {
		return "Student [studentId=" + studentId + ", studentCity=" + studentCity + ", score=" + score + "]";
	}

	/*
	 * String str1="Internet" str2="Intercon"
	 * str1.compareTo(str2)
	 * 
	 */
/*	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		if ( (this.studentId.compareTo(o.studentId)) > 0 )
		{
			return 1;
		}
		else if( (this.studentId.compareTo(o.studentId)) < 0 )
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}*/
	 /*@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		if ( (this.studentCity.compareTo(o.studentCity)) > 0 )
		{
			return 1;
		}
		else if( (this.studentCity.compareTo(o.studentCity)) < 0 )
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}*/
	@Override
	public int compareTo(Student o) {
		// TODO Auto-generated method stub
		if ( this.score > o.score )
		{
			return 1;
		}
		else if( this.score < o.score   )
		{
			return -1;
		}
		else
		{
			return 0;
		}
	}
	/*
	 * s1 s2 s3 s4
	 * 
	 * 
	 */
}

import java.util.Calendar;
import java.util.Date;

public class MyCalendarSample {

	public void manipulateDate()
	{
		Date date1 = new Date();
		System.out.println("The Date is "+date1.getDate());
		System.out.println("The Day is "+date1.getDay());
		System.out.println("The MOnth is "+date1.getMonth());
		System.out.println("The Year is "+date1.getYear());
		System.out.println("The Full Year is "+(date1.getYear()+1900));
		System.out.println("The Hour is "+date1.getHours());
		System.out.println("The Minute is "+date1.getMinutes());
		System.out.println("The Second is "+date1.getSeconds());
	}
	public void manipulateCalendar()
	{
		String[] months = {"Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"};
		String[] days = {"Sat","Sun","Mon","Tue","Wed","Thu","Fri"};
		Calendar cal = Calendar.getInstance();
		System.out.println("Month is Represented By a NUm "+cal.MONTH);
		System.out.println("Month is "+cal.get(cal.MONTH));
		System.out.println("Month is "+months[cal.get(cal.MONTH)]);
		
		System.out.println("Date is "+cal.get(cal.DATE));
		System.out.println("Day Of Month is "+cal.get(cal.DAY_OF_MONTH));
		System.out.println("Day Of Week is "+cal.get(cal.DAY_OF_WEEK));
		System.out.println("Day Of Week is "+days[cal.get(cal.DAY_OF_WEEK)]);
		System.out.println("Year is "+cal.get(cal.YEAR));
		System.out.println("Hour  is "+cal.get(cal.HOUR_OF_DAY));
		System.out.println("Minute is "+cal.get(cal.MINUTE));
		System.out.println("Second  is "+cal.get(cal.SECOND));
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyCalendarSample mcs = new MyCalendarSample();
		mcs.manipulateDate();
		System.out.println("-----------------------------------------------");
		mcs.manipulateCalendar();

	}

}

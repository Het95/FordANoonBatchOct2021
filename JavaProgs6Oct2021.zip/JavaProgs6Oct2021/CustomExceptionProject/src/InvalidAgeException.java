
public class InvalidAgeException extends Exception{

	public String getMessage()
	{
		return "Sorry Invalid Age !!! Valid Age is between 20 and 30 ";
	}
}

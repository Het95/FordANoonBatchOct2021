
public class Recruitment {

	public void checkAge(int age) throws InvalidAgeException
	{
		System.out.println("Scrutinization Continued...");
		System.out.println("About to Check Age...");
		if((age < 20)||(age > 30))
		{
			throw new InvalidAgeException();
		}
		System.out.println("Valid Age and Age is "+age);
		System.out.println("Can continue for further Scrutinization...");
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub

		Recruitment rc = new Recruitment();
		System.out.println("Recruitment Process on...");
		System.out.println("About to validate Age...");
		try
		{
			rc.checkAge(23);
			rc.checkAge(26);
			rc.checkAge(32);
			rc.checkAge(27);
			rc.checkAge(28);
		}
			catch(InvalidAgeException iae)
		{
			System.out.println(iae.getMessage());
		}/**/
		finally
		{
			System.out.println("Anyways We are in Finally...");
		}
			System.out.println("Recruitment Process Completed...");
			System.out.println("We are exiting Main...");
			
	}

}

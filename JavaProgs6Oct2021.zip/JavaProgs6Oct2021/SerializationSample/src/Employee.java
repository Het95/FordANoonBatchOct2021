import java.io.Serializable;

public class Employee implements Serializable{

	String employeeId;
	String employeeName;
	String employeeAddress;
	String employeePhone;
	int employeeSalary;
	/*transient*/ float empTax;
	
	
	public Employee() {
		super();
	}


	public Employee(String employeeId, String employeeName, String employeeAddress, String employeePhone,
			int employeeSalary, float empTax) {
		super();
		this.employeeId = employeeId;
		this.employeeName = employeeName;
		this.employeeAddress = employeeAddress;
		this.employeePhone = employeePhone;
		this.employeeSalary = employeeSalary;
		this.empTax = empTax;
	}


	public String getEmployeeId() {
		return employeeId;
	}


	public void setEmployeeId(String employeeId) {
		this.employeeId = employeeId;
	}


	public String getEmployeeName() {
		return employeeName;
	}


	public void setEmployeeName(String employeeName) {
		this.employeeName = employeeName;
	}


	public String getEmployeeAddress() {
		return employeeAddress;
	}


	public void setEmployeeAddress(String employeeAddress) {
		this.employeeAddress = employeeAddress;
	}


	public String getEmployeePhone() {
		return employeePhone;
	}


	public void setEmployeePhone(String employeePhone) {
		this.employeePhone = employeePhone;
	}


	public int getEmployeeSalary() {
		return employeeSalary;
	}


	public void setEmployeeSalary(int employeeSalary) {
		this.employeeSalary = employeeSalary;
	}


	public float getEmpTax() {
		return empTax;
	}


	public void setEmpTax(float empTax) {
		this.empTax = empTax;
	}


	@Override
	public String toString() {
		return "Employee [employeeId=" + employeeId + ", employeeName=" + employeeName + ", employeeAddress="
				+ employeeAddress + ", employeePhone=" + employeePhone + ", employeeSalary=" + employeeSalary
				+ ", empTax=" + empTax + "]";
	}
	
	
	
	
}

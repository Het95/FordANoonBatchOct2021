import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class BufferedStreamByteWriter {

	BufferedOutputStream bos;
	String str = "we are writing bytes thru buffer to our file";
	byte myBytes[] = new byte[100];
	public void writeToByteStream()
	{
		try 
		{
			myBytes = str.getBytes();
			bos = new BufferedOutputStream(new FileOutputStream("Supplier.txt"));
		//	bos = new BufferedOutputStream(new FileOutputStream("xyz.txt"),1000);
			bos.write(myBytes);
			bos.flush();
			bos.close();
			System.out.println("We Have written successully into file using Buffer thru Streams...");
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedStreamByteWriter bsbw = new BufferedStreamByteWriter();
		bsbw.writeToByteStream();

	}

}

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class BufferedStreamByteReader {

	BufferedInputStream bis;
	byte myBytes[] = new byte[100];
	public void readFromByteStream()
	{
		try 
		{
			bis = new BufferedInputStream(new FileInputStream("Supplier.txt"));
			bis.read(myBytes);
			String str = new String(myBytes);
			bis.close();
			System.out.println("The Binary Data that was Read thru Buffer is :"+str);
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch(IOException ioe)
		{
			ioe.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		BufferedStreamByteReader bsbr = new BufferedStreamByteReader();
		bsbr.readFromByteStream();

	}

}

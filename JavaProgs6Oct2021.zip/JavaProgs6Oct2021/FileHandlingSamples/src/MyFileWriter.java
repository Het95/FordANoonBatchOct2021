import java.io.FileWriter;
import java.io.IOException;

public class MyFileWriter {

	FileWriter fw;
	String str = "We are writing text into Char Stream";
	public void writeToCharStream()
	{
		try 
		{
			fw = new FileWriter("employees.txt");
			fw.write(str);
			fw.flush();
			fw.close();
			System.out.println("We Have written Successfully into char stream");
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		MyFileWriter mfw = new MyFileWriter();
		mfw.writeToCharStream();
	}

}

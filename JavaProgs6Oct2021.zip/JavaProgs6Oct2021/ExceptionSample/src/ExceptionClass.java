
public class ExceptionClass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are In Main....");
		System.out.println("We are about to call Calculate function....");
		Calculator calci = new Calculator();
	/*	try
		{*/
			calci.calculate(100, 20);
			calci.calculate(100, 50);
			calci.calculate(100, 0);
			calci.calculate(100, 10);
			calci.calculate(100, 25);
		/*}
		catch(ArithmeticException ae)
		{
			System.out.println(ae.getMessage());
		}
		catch(Exception ex)
		{
			System.out.println(ex.getMessage());
		}*/
		System.out.println("We finished call to Calculate function..");
		System.out.println("We are exiting Main...");
	}

}

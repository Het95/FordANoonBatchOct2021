class ArraySample
{
	public void populateAndDisplayArray()
	{
		int arr[] = new int[10];
		System.out.println("We are about to Populate & Display Array...");
		try
		{
			for(int i=0;i<=10;i++)
			{
				arr[i] = (i+1)*10;
				System.out.println("The Element is "+arr[i]);
			}
		}
		catch(ArrayIndexOutOfBoundsException aie)
		{
			System.out.println(aie.getMessage());
		}
		System.out.println("We finished Displaying Array Elements....");
	}
	
	
}
public class ArrayIndexSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("We are In Main...");
		System.out.println("We are about to call Array Manipulator...");
		ArraySample asp = new ArraySample();
		asp.populateAndDisplayArray();
		System.out.println("We finished call...");
		System.out.println("We are about to Exit Main...");

	}

}

import java.util.StringTokenizer;

public class MyStringSample {
	
	public static void main(String[] args)
	{
		/*
		String str1 = "Bangalore";
		String str2 = "Chennai";
		
		System.out.println("str1.equals(str2) :"+str1.equals(str2));//False
		System.out.println("str1==str2) :"+(str1 == str2));//False
		
		System.out.println("-------------------------------------");
		
		String str3 = "Bangalore";
		String str4 = "Bangalore";
		
		System.out.println("str3.equals(str4) :"+str3.equals(str4));//True
		System.out.println("str3==str4) :"+(str3 == str4));//TRUE
		
		str3 = str4;
		System.out.println("str3.equals(str4) :"+str3.equals(str4));//True
		System.out.println("str3==str4) :"+(str3 == str4));//TRUE
		System.out.println("---------------------------------------------------");
		
		String str5 = new String("Bangalore");
		String str6 = new String("Bangalore");
		
		System.out.println("str5.equals(str6) :"+str5.equals(str6));//TRUE
		System.out.println("str5==str6) :"+(str5 == str6));//FALSE
		System.out.println("---------------------------------------------------");
		str5 = str6;
		
		System.out.println("str5.equals(str6) :"+str5.equals(str6));//TRUE
		System.out.println("str5==str6) :"+(str5 == str6));//TRUE */
		
		System.out.println("---------------------------------");
		StringBuilder sbr1 = new StringBuilder("This is new world");
		System.out.println("STring Builder is "+sbr1);
		sbr1.append('A');
		System.out.println("String builder after appending Character");
		System.out.println("STring Builder is "+sbr1);
		System.out.println("---------------------------------");
		StringBuffer sbfr1 = new StringBuffer("This is new Buffer world");
		System.out.println("STring Buffer is "+sbfr1);
		sbfr1.append('A');
		System.out.println("String Buffer after appending Character");
		System.out.println("STring Buffer is "+sbr1);
		System.out.println("---------------------------------");
		//---------------StringBuffer is Synchronized
		//---------------StringBuider is Not Synchronized
		char[] chars= {'A','E','I','O','U'};
		
		sbfr1.append(chars);
		System.out.println("String Buffer after appending char array "+sbfr1);
		
		sbr1.append(chars);
		System.out.println("String Builder after appending char array "+sbr1);
		
		sbr1.append(" New World");
		System.out.println("String Builder after appending String "+sbr1);
		System.out.println("---------------------------------");
		StringBuilder sbr2 = new StringBuilder("Hello World");
		System.out.println("The String "+sbr2+"The Capacity is "+sbr2.capacity());
		//sbr2 = "Hello Worldabcasdfghjkdlsjkk";
		sbr2.append("abcasdfghjkdlsjkk");
		System.out.println("The String "+sbr2+"The Capacity is "+sbr2.capacity());
		sbr2.charAt(10);
		System.out.println("sbr2.charAt(10) : "+sbr2.charAt(10));
		System.out.println("---------------------------------");
		String strx = new String("Hello World");
		System.out.println(" strx.charAt(10) "+strx.charAt(10));
		System.out.println("strx.codePointAt(10) "+strx.codePointAt(10));
		String stry = new String("One:Two:Three:Four");
		String[] splitStrings = stry.split(":");
		
		for(String str:splitStrings)
		{
			System.out.println("String in Array is "+str);
		}
		
		//www.rediffmail.com/login?login=''&password=''&
		System.out.println("--------------StringTokenizer-------------------");
		StringTokenizer strToken = new StringTokenizer("This:Is:A:Sample:Tokens",":");
		
		while(strToken.hasMoreTokens())
		{
			System.out.println("The Token is :"+strToken.nextToken());
		}
		System.out.println("--------------StringTokenizer-------------------");
		while(strToken.hasMoreElements())
		{
			System.out.println("The Token is :"+strToken.nextElement());
		}
	}

}

import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.Set;

public class HashTableSample {

	Hashtable ht = new Hashtable();
	 
	public void populateHashTable()
	{
		ht.put("E001", 10000);
		ht.put("E002", 11000);
		ht.put("E003", 12000);
		ht.put("E004", 13000);
		ht.put("E005", 14000);
		ht.put("E006", 15000);
		ht.put("E007", 16000);
		ht.put("E007", 17000);
		
	}
	public void traverseHashTable()
	{
		Enumeration myKeys = ht.keys();
		
		while(myKeys.hasMoreElements())
		{
			String idStr = (String)myKeys.nextElement();
			System.out.println("The Value for the Key "+idStr+" is :"+ht.get(idStr));
		}
		
	}
	
	public void traverseKeySet()
	{
		Set myKeys = ht.keySet();
		Iterator keyIter = myKeys.iterator();
		while(keyIter.hasNext())
		{
			String idKey = (String)keyIter.next();
			System.out.println("The Value for the Key "+idKey+" is :"+ht.get(idKey));
			
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		HashTableSample hts = new HashTableSample();
		hts.populateHashTable();
		hts.traverseHashTable();
		System.out.println("------------KeySet USage-----------");
		hts.traverseKeySet();

	}

}

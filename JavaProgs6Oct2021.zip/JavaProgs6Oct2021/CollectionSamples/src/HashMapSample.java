import java.util.Collection;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Set;

public class HashMapSample {

	HashMap <String,Integer> myMap = new HashMap <String,Integer> ();
	HashMap <String,Customer> myMap1 = new HashMap <String,Customer>();
	public void populateHashMap()
	{
		myMap.put("E001", 10000);
		myMap.put("E002", 11000);
		myMap.put("E003", 12000);
		myMap.put("E004", 13000);
		myMap.put("E005", 14000);
		myMap.put("E006", 15000);
		myMap.put("E007", 16000);
		myMap.put("E007", 17000);
		
		myMap1.put("C1",new Customer("C001","Harsha","RTNagar",10000,12.34f));
		
		
	}
	public void fetchHashMap()
	{
		Set <String> myKeys = myMap.keySet();
		Iterator keyIter = myKeys.iterator();
		while(keyIter.hasNext())
		{
			String sKey = (String)keyIter.next();
			System.out.println("The Value for the Key "+sKey+" is "+myMap.get(sKey));
			
		}
		System.out.println("----------The Values Alone---------------");
		Collection c = myMap.values();
		Iterator cIter = c.iterator();
		while(cIter.hasNext())
		{
			System.out.println("The Value is "+cIter.next());
		}
		
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMapSample hms = new HashMapSample();
		hms.populateHashMap();
		hms.fetchHashMap();
	}

}

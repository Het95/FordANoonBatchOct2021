
public class CastingSample {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		/*
		 * Widening Cast-Implicit

		byte ->short ->char ->int ->long->float->double

		Narrowing Cast-Explicit

		double->float->long->int ->char->short->byte
		 */
		byte byte1 = 100;
		short short1 = 300;
		//Narrow Casting -Explicit
		byte1 = (byte)short1;
		System.out.println("after short to byte explicit :"+byte1);
		
		//Widening Cast - Implicit
		byte byte2 = 125;
		short short2 = 400;
		short2 = byte2;
		System.out.println("after byte to short implicit :"+short2);
		
		
		long lVar = 20000;
		float fVar = 123.45f;
		
		fVar = lVar;
		System.out.println("fVar after implicit casting "+fVar);
		
		
		float fVar1 = 123.456f;
		long lVar1 = 20000;
		lVar1 = (long)fVar1;
		System.out.println("lVar1 after explicit cast from float to long "+lVar1);
		
	}

}
